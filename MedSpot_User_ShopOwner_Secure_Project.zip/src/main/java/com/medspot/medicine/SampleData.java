package com.medspot.medicine;

import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class SampleData {
    @Bean
    CommandLineRunner addSampleData(MedicineRepository repo) {
        return args -> {
            if (repo.count() == 0) {
                // Example coordinates in Chennai. Verify real locations and stock before using outside a demo.
                repo.save(new Medicine("Paracetamol 500mg", "MediCare Corner Pharmacy", "T. Nagar, Chennai",
                    40, 12.50, 13.0418, 80.2337, 0L));
                repo.save(new Medicine("Cetirizine 10mg", "Wellness & Life Pharmacy", "Nungambakkam, Chennai",
                    18, 20.00, 13.0569, 80.2425, 0L));
                repo.save(new Medicine("Ibuprofen 400mg", "City Core Pharmacy", "Anna Nagar, Chennai",
                    0, 35.00, 13.0850, 80.2101, 0L));
                repo.save(new Medicine("Amoxicillin 250mg", "MediCare Corner Pharmacy", "T. Nagar, Chennai",
                    15, 48.00, 13.0418, 80.2337, 0L));
            }
        };
    }
}
