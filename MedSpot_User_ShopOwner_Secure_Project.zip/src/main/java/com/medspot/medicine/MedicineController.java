package com.medspot.medicine;

import com.medspot.user.AppUser;
import com.medspot.user.UserRepository;
import jakarta.servlet.http.HttpSession;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/medicines")
public class MedicineController {
    private final MedicineRepository medicines;
    private final UserRepository users;

    public MedicineController(MedicineRepository medicines, UserRepository users) {
        this.medicines = medicines; this.users = users;
    }

    record MedicineRequest(String name, String pharmacy, String address, Integer stock,
                           Double price, Double latitude, Double longitude) {}

    @GetMapping
    public List<Medicine> search(@RequestParam(defaultValue = "") String name) {
        return name.isBlank() ? medicines.findAll() : medicines.findByNameContainingIgnoreCase(name.trim());
    }

    @GetMapping("/mine")
    public List<Medicine> mine(HttpSession session) {
        AppUser user = requireRole(session, "SHOP_OWNER");
        return medicines.findByOwnerId(user.getId());
    }

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public Medicine add(@RequestBody MedicineRequest req, HttpSession session) {
        AppUser owner = requireRole(session, "SHOP_OWNER");
        validate(req);
        return medicines.save(new Medicine(req.name().trim(), req.pharmacy().trim(), req.address().trim(),
            req.stock(), req.price(), req.latitude(), req.longitude(), owner.getId()));
    }

    @PutMapping("/{id}")
    public Medicine update(@PathVariable Long id, @RequestBody MedicineRequest req, HttpSession session) {
        AppUser owner = requireRole(session, "SHOP_OWNER");
        validate(req);
        Medicine item = medicines.findById(id).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Listing not found."));
        if (!item.getOwnerId().equals(owner.getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only update your own listings.");
        item.setName(req.name().trim()); item.setPharmacy(req.pharmacy().trim());
        item.setAddress(req.address().trim()); item.setStock(req.stock()); item.setPrice(req.price());
        item.setLatitude(req.latitude()); item.setLongitude(req.longitude());
        return medicines.save(item);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id, HttpSession session) {
        AppUser owner = requireRole(session, "SHOP_OWNER");
        Medicine item = medicines.findById(id).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.NOT_FOUND, "Listing not found."));
        if (!item.getOwnerId().equals(owner.getId()))
            throw new ResponseStatusException(HttpStatus.FORBIDDEN, "You can only delete your own listings.");
        medicines.delete(item);
    }

    private AppUser requireRole(HttpSession session, String role) {
        Long id = (Long) session.getAttribute("userId");
        if (id == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in first.");
        AppUser user = users.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        if (!role.equals(user.getRole())) throw new ResponseStatusException(HttpStatus.FORBIDDEN, "This feature is for " + role + " accounts.");
        return user;
    }
    private void validate(MedicineRequest r) {
        if (r == null || blank(r.name()) || r.name().trim().length() > 120 ||
            blank(r.pharmacy()) || r.pharmacy().trim().length() > 120 ||
            blank(r.address()) || r.address().trim().length() > 250 ||
            r.stock() == null || r.stock() < 0 ||
            r.price() == null || !Double.isFinite(r.price()) || r.price() < 0 ||
            r.latitude() == null || !Double.isFinite(r.latitude()) || r.latitude() < -90 || r.latitude() > 90 ||
            r.longitude() == null || !Double.isFinite(r.longitude()) || r.longitude() < -180 || r.longitude() > 180) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Check all fields, stock, price and valid map coordinates.");
        }
    }
    private boolean blank(String s) { return s == null || s.trim().isEmpty(); }
}
