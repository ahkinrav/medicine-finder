package com.medspot.medicine;

import jakarta.persistence.*;

@Entity
@Table(name = "medicines")
public class Medicine {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(nullable = false, length = 120)
    private String name;
    @Column(nullable = false, length = 120)
    private String pharmacy;
    @Column(nullable = false, length = 250)
    private String address;
    @Column(nullable = false)
    private int stock;
    @Column(nullable = false)
    private double price;
    @Column(nullable = false)
    private double latitude;
    @Column(nullable = false)
    private double longitude;
    @Column(nullable = false)
    private Long ownerId;

    protected Medicine() {}
    public Medicine(String name, String pharmacy, String address, int stock, double price,
                    double latitude, double longitude, Long ownerId) {
        this.name=name; this.pharmacy=pharmacy; this.address=address; this.stock=stock;
        this.price=price; this.latitude=latitude; this.longitude=longitude; this.ownerId=ownerId;
    }
    public Long getId(){return id;} public String getName(){return name;}
    public String getPharmacy(){return pharmacy;} public String getAddress(){return address;}
    public int getStock(){return stock;} public double getPrice(){return price;}
    public double getLatitude(){return latitude;} public double getLongitude(){return longitude;}
    public Long getOwnerId(){return ownerId;}
    public void setId(Long v){id=v;} public void setName(String v){name=v;}
    public void setPharmacy(String v){pharmacy=v;} public void setAddress(String v){address=v;}
    public void setStock(int v){stock=v;} public void setPrice(double v){price=v;}
    public void setLatitude(double v){latitude=v;} public void setLongitude(double v){longitude=v;}
}
