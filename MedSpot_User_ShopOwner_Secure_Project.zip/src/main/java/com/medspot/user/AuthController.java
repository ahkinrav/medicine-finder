package com.medspot.user;

import jakarta.servlet.http.HttpSession;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Pattern;
import org.springframework.http.HttpStatus;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

@RestController
@RequestMapping("/api/auth")
public class AuthController {
    private final UserRepository users;
    private final PasswordEncoder encoder;
    private static final Pattern EMAIL = Pattern.compile("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$");

    public AuthController(UserRepository users, PasswordEncoder encoder) {
        this.users = users; this.encoder = encoder;
    }

    record RegisterRequest(String name, String email, String password, String role) {}
    record LoginRequest(String email, String password) {}

    @PostMapping("/register")
    @ResponseStatus(HttpStatus.CREATED)
    public Map<String, Object> register(@RequestBody RegisterRequest req, HttpSession session) {
        String name = clean(req.name());
        String email = clean(req.email()).toLowerCase(Locale.ROOT);
        String role = clean(req.role()).toUpperCase(Locale.ROOT);
        if (name.length() < 2 || name.length() > 80) throw bad("Name must be 2–80 characters.");
        if (!EMAIL.matcher(email).matches() || email.length() > 150) throw bad("Enter a valid email address.");
        if (req.password() == null || req.password().length() < 8 || req.password().length() > 72)
            throw bad("Password must contain 8–72 characters.");
        if (!role.equals("USER") && !role.equals("SHOP_OWNER")) throw bad("Choose User or Shop Owner.");
        if (users.existsByEmailIgnoreCase(email)) throw new ResponseStatusException(HttpStatus.CONFLICT, "This email is already registered.");
        AppUser saved = users.save(new AppUser(name, email, encoder.encode(req.password()), role));
        session.setAttribute("userId", saved.getId());
        return publicUser(saved);
    }

    @PostMapping("/login")
    public Map<String, Object> login(@RequestBody LoginRequest req, HttpSession session) {
        String email = clean(req.email()).toLowerCase(Locale.ROOT);
        AppUser user = users.findByEmailIgnoreCase(email).orElseThrow(() ->
            new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Email or password is incorrect."));
        if (req.password() == null || !encoder.matches(req.password(), user.getPasswordHash()))
            throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Email or password is incorrect.");
        session.setAttribute("userId", user.getId());
        return publicUser(user);
    }

    @GetMapping("/me")
    public Map<String, Object> me(HttpSession session) {
        Long id = (Long) session.getAttribute("userId");
        if (id == null) throw new ResponseStatusException(HttpStatus.UNAUTHORIZED, "Please log in.");
        AppUser user = users.findById(id).orElseThrow(() -> new ResponseStatusException(HttpStatus.UNAUTHORIZED));
        return publicUser(user);
    }

    @PostMapping("/logout")
    public Map<String, String> logout(HttpSession session) {
        session.invalidate();
        return Map.of("message", "Logged out.");
    }

    private Map<String, Object> publicUser(AppUser u) {
        return Map.of("id", u.getId(), "name", u.getName(), "email", u.getEmail(), "role", u.getRole());
    }
    private String clean(String s) { return s == null ? "" : s.trim(); }
    private ResponseStatusException bad(String message) { return new ResponseStatusException(HttpStatus.BAD_REQUEST, message); }
}
