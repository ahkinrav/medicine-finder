package com.medspot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MedSpotApplication {
    public static void main(String[] args) {
        SpringApplication.run(MedSpotApplication.class, args);
    }
}
