const $ = id => document.getElementById(id);
let currentUser = null, userCoords = null, authMode = "login", editingId = null, cachedMedicines = [];

function esc(v){return String(v ?? "").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function money(v){return new Intl.NumberFormat("en-IN",{style:"currency",currency:"INR"}).format(v);}
async function api(url, options={}) {
  const response = await fetch(url,{credentials:"same-origin",...options,headers:{"Content-Type":"application/json",...(options.headers||{})}});
  if(response.status===204) return null;
  const body=await response.json().catch(()=>({}));
  if(!response.ok) throw new Error(body.message || body.error || `Request failed (${response.status})`);
  return body;
}
function distanceKm(a,b,c,d){
 const rad=x=>x*Math.PI/180, R=6371, dLat=rad(c-a), dLon=rad(d-b);
 const h=Math.sin(dLat/2)**2+Math.cos(rad(a))*Math.cos(rad(c))*Math.sin(dLon/2)**2;
 return 2*R*Math.asin(Math.sqrt(Math.min(1,h)));
}
function setNotice(msg){$("notice").textContent=msg;}
function showAuth(mode="login"){$("authModal").classList.remove("hidden");setAuthMode(mode);}
function hideAuth(){$("authModal").classList.add("hidden");}
function setAuthMode(mode){
 authMode=mode;
 document.querySelectorAll(".tab").forEach(b=>b.classList.toggle("active",b.dataset.tab===mode));
 $("nameWrap").classList.toggle("hidden",mode!=="register");
 $("roleWrap").classList.toggle("hidden",mode!=="register");
 $("authName").required=mode==="register";
 $("authTitle").textContent=mode==="login"?"Welcome back.":"Create your MedSpot account.";
 $("authSubmit").textContent=mode==="login"?"Login":"Create account";
 $("authPassword").autocomplete=mode==="login"?"current-password":"new-password";
 $("authNotice").textContent="";
}
function renderSession(){
 $("who").textContent=currentUser?`${currentUser.name} · ${currentUser.role==="SHOP_OWNER"?"Shop owner":"User"}`:"Guest mode";
 $("openAuth").classList.toggle("hidden",!!currentUser);
 $("logoutBtn").classList.toggle("hidden",!currentUser);
 $("ownerPanel").classList.toggle("hidden",!currentUser||currentUser.role!=="SHOP_OWNER");
 if(currentUser?.role==="SHOP_OWNER") loadMine();
}
async function refreshMe(){
 try{currentUser=await api("/api/auth/me");}catch{currentUser=null;}
 renderSession();
}
async function loadMedicines(){
 setNotice("Loading medicine listings…");$("results").innerHTML="";
 try{
  const list=await api(`/api/medicines?name=${encodeURIComponent($("searchInput").value.trim())}`);
  cachedMedicines=list;renderMedicines(list);
 }catch(e){setNotice("Couldn't load listings. Check that Spring Boot and MySQL are running.");$("results").innerHTML=`<div class="empty">${esc(e.message)}</div>`;}
}
function renderMedicines(list){
 $("resultHeading").textContent=$("searchInput").value.trim()?`Results for “${$("searchInput").value.trim()}”`:"Explore medicine listings";
 setNotice(`${list.length} listing${list.length===1?"":"s"} · Demo inventory — call the pharmacy to confirm.`);
 if(!list.length){$("results").innerHTML='<div class="empty">No matches found. Try a different medicine name.</div>';return;}
 const sorted=[...list].sort((a,b)=>{
  if(userCoords){return distanceKm(userCoords.lat,userCoords.lng,a.latitude,a.longitude)-distanceKm(userCoords.lat,userCoords.lng,b.latitude,b.longitude);}
  return a.name.localeCompare(b.name);
 });
 $("results").innerHTML=sorted.map(m=>{
  const distance=userCoords?`<div class="distance">⌖ About ${distanceKm(userCoords.lat,userCoords.lng,m.latitude,m.longitude).toFixed(1)} km from your location</div>`:"";
  const maps=`https://www.google.com/maps/dir/?api=1&destination=${encodeURIComponent(m.latitude+","+m.longitude)}`;
  return `<article class="medicine-card"><div class="med-icon">✚</div><div class="card-top"><div><h3>${esc(m.name)}</h3><div class="pharmacy">${esc(m.pharmacy)}</div></div><span class="stock ${m.stock===0?"out":""}">${m.stock===0?"Out of stock":`${m.stock} listed`}</span></div><p class="address">⌖ ${esc(m.address)}</p>${distance}<div class="card-bottom"><span class="price">${money(m.price)} <small>/ listed price</small></span><a class="map-link" href="${maps}" target="_blank" rel="noopener noreferrer">Directions ↗</a></div></article>`;
 }).join("");
}
$("searchForm").addEventListener("submit",e=>{e.preventDefault();loadMedicines();});
document.querySelectorAll("[data-search]").forEach(b=>b.addEventListener("click",()=>{$("searchInput").value=b.dataset.search;loadMedicines();}));
$("openAuth").addEventListener("click",()=>showAuth("login"));
$("closeAuth").addEventListener("click",hideAuth);
$("authModal").addEventListener("click",e=>{if(e.target===$("authModal"))hideAuth();});
document.querySelectorAll(".tab").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.tab)));

$("authForm").addEventListener("submit",async e=>{
 e.preventDefault();$("authSubmit").disabled=true;$("authNotice").textContent="Please wait…";
 try{
  const payload={email:$("authEmail").value.trim(),password:$("authPassword").value};
  const endpoint=authMode==="login"?"/api/auth/login":"/api/auth/register";
  if(authMode==="register"){payload.name=$("authName").value.trim();payload.role=$("authRole").value;}
  currentUser=await api(endpoint,{method:"POST",body:JSON.stringify(payload)});
  $("authNotice").textContent="Success!";
  hideAuth();$("authForm").reset();await loadMedicines();renderSession();
 }catch(err){$("authNotice").textContent=err.message||"Unable to continue.";}
 finally{$("authSubmit").disabled=false;}
});
$("logoutBtn").addEventListener("click",async()=>{try{await api("/api/auth/logout",{method:"POST",body:"{}"});}catch{}currentUser=null;renderSession();await loadMedicines();});
function getLocation(){
 return new Promise((resolve,reject)=>{
  if(!navigator.geolocation){reject(new Error("This browser does not support location."));return;}
  navigator.geolocation.getCurrentPosition(pos=>resolve({lat:pos.coords.latitude,lng:pos.coords.longitude}),err=>{
   const msg=err.code===1?"Location permission was denied. Allow location access in the browser.":err.code===2?"Your location is unavailable. Try again or enter shop coordinates manually.":"Location request timed out. Try again.";
   reject(new Error(msg));
  },{enableHighAccuracy:true,timeout:12000,maximumAge:60000});
 });
}
$("locateBtn").addEventListener("click",async()=>{
 $("locateBtn").disabled=true;$("locateBtn").textContent="Finding location…";
 try{userCoords=await getLocation();$("locateBtn").textContent="✓ Location enabled";await loadMedicines();}
 catch(e){setNotice(e.message);$("locateBtn").textContent="⌖ Use my location";}
 finally{$("locateBtn").disabled=false;}
});
$("shopLocationBtn").addEventListener("click",async()=>{
 $("ownerNotice").textContent="Requesting location permission…";
 try{const c=await getLocation();$("mLat").value=c.lat.toFixed(6);$("mLng").value=c.lng.toFixed(6);$("ownerNotice").textContent="Coordinates filled in. Check that these are the pharmacy's actual coordinates before saving.";}
 catch(e){$("ownerNotice").textContent=e.message;}
});
function resetMedicineForm(){
 editingId=null;$("medicineForm").reset();$("medicineId").value="";$("mStock").value=10;$("mPrice").value=25;
 $("cancelEdit").classList.add("hidden");$("ownerNotice").textContent="";
}
$("cancelEdit").addEventListener("click",resetMedicineForm);
$("medicineForm").addEventListener("submit",async e=>{
 e.preventDefault();if(!currentUser||currentUser.role!=="SHOP_OWNER"){showAuth("login");return;}
 const payload={name:$("mName").value.trim(),pharmacy:$("mPharmacy").value.trim(),address:$("mAddress").value.trim(),stock:Number($("mStock").value),price:Number($("mPrice").value),latitude:Number($("mLat").value),longitude:Number($("mLng").value)};
 $("ownerNotice").textContent="Saving listing…";
 try{
  const id=editingId;await api(id?`/api/medicines/${id}`:"/api/medicines",{method:id?"PUT":"POST",body:JSON.stringify(payload)});
  $("ownerNotice").textContent="Listing saved successfully.";resetMedicineForm();await loadMedicines();await loadMine();
 }catch(err){$("ownerNotice").textContent=err.message;}
});
async function loadMine(){
 if(!currentUser||currentUser.role!=="SHOP_OWNER")return;
 try{
  const list=await api("/api/medicines/mine");
  $("myListings").innerHTML=list.length?list.map(m=>`<div class="mine-row"><div><strong>${esc(m.name)}</strong><br><span class="sub">${esc(m.pharmacy)} · Stock: ${m.stock} · ${money(m.price)}</span></div><div class="mine-actions"><button data-edit="${m.id}">Edit</button><button data-delete="${m.id}">Delete</button></div></div>`).join(""):'<div class="empty">No listings yet. Use the form above to add your first medicine.</div>';
  $("myListings").querySelectorAll("[data-edit]").forEach(b=>b.addEventListener("click",()=>{
   const m=list.find(x=>x.id===Number(b.dataset.edit));if(!m)return;editingId=m.id;
   $("mName").value=m.name;$("mPharmacy").value=m.pharmacy;$("mAddress").value=m.address;$("mStock").value=m.stock;$("mPrice").value=m.price;$("mLat").value=m.latitude;$("mLng").value=m.longitude;$("cancelEdit").classList.remove("hidden");$("ownerNotice").textContent="Editing listing #"+m.id;
   $("ownerPanel").scrollIntoView({behavior:"smooth",block:"start"});
  }));
  $("myListings").querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",async()=>{
   if(!confirm("Delete this medicine listing?"))return;
   try{await api(`/api/medicines/${b.dataset.delete}`,{method:"DELETE"});await loadMine();await loadMedicines();}
   catch(err){$("ownerNotice").textContent=err.message;}
  }));
 }catch(e){$("ownerNotice").textContent=e.message;}
}
(async()=>{await refreshMe();await loadMedicines();})();
